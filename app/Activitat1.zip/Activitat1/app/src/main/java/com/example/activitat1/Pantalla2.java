package com.example.activitat1;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class Pantalla2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla2);
    }
}